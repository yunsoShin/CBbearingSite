import React from 'react';

export default function BearingDetail() {
    return (
        <div>
            
        </div>
    );
}

