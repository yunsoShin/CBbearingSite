import React from 'react';
import QnAlist from '../Component/Questions';
import Questions from '../Component/Questions';


export default function Contact() {
    return (
        <div>
            <Questions></Questions>
            <li>리스트</li>
        </div>
    )
}