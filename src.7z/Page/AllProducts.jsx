import React from 'react';
import Products from '../Component/Products';

export default function AllProducts() {
  return <Products></Products>;
}
